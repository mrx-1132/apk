# Defaults are sufficient; MediaPipe ships its own consumer rules.
