package com.airgesture.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.airgesture.app.MainActivity
import com.airgesture.app.R
import com.airgesture.app.accessibility.AirGestureAccessibilityService
import com.airgesture.app.accessibility.SwipeDirection
import com.airgesture.app.camera.FrontCameraManager
import com.airgesture.app.detection.GestureConfig
import com.airgesture.app.detection.GestureDetector
import com.airgesture.app.detection.HandDetector
import com.airgesture.app.detection.SwipeGesture

/**
 * Foreground service (type "camera") that owns the full detection pipeline:
 * FrontCameraManager -> HandDetector -> GestureDetector -> AccessibilityService.
 *
 * It only runs while the user has explicitly enabled Air Gesture. It stops
 * itself, releasing the camera and MediaPipe resources, whenever the app is
 * disabled, the accessibility service becomes unavailable, or an
 * unrecoverable pipeline error occurs.
 */
class AirGestureForegroundService : LifecycleService() {

    companion object {
        private const val TAG = "AirGestureService"
        private const val CHANNEL_ID = "air_gesture_active"
        private const val NOTIFICATION_ID = 1001

        const val EXTRA_SENSITIVITY = "sensitivity"
        const val EXTRA_COOLDOWN_MS = "cooldown_ms"
        const val ACTION_START = "com.airgesture.app.action.START"
        const val ACTION_STOP = "com.airgesture.app.action.STOP"

        fun start(context: Context, sensitivity: Float, cooldownMs: Long) {
            val intent = Intent(context, AirGestureForegroundService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_SENSITIVITY, sensitivity)
                putExtra(EXTRA_COOLDOWN_MS, cooldownMs)
            }
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, AirGestureForegroundService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    private var cameraManager: FrontCameraManager? = null
    private var handDetector: HandDetector? = null
    private var gestureDetector: GestureDetector? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_STOP -> {
                stopPipeline()
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                val sensitivity = intent?.getFloatExtra(EXTRA_SENSITIVITY, 0.5f) ?: 0.5f
                val cooldownMs = intent?.getLongExtra(EXTRA_COOLDOWN_MS, 900L) ?: 900L
                startForegroundWithNotification()
                startPipeline(sensitivity, cooldownMs)
            }
        }
        return START_NOT_STICKY
    }

    private fun startPipeline(sensitivity: Float, cooldownMs: Long) {
        if (!AirGestureAccessibilityService.isEnabledInSystemSettings(this)) {
            Log.w(TAG, "Accessibility service not enabled; stopping.")
            stopPipeline()
            stopSelf()
            return
        }

        val config = GestureConfig.fromSensitivity(sensitivity, cooldownMs)
        val detector = GestureDetector(config)
        gestureDetector = detector

        val hand = HandDetector(
            context = this,
            onResult = { sample ->
                when (detector.process(sample)) {
                    SwipeGesture.SWIPE_NEXT -> AirGestureAccessibilityService.requestSwipe(SwipeDirection.NEXT_PAGE)
                    SwipeGesture.SWIPE_PREVIOUS -> AirGestureAccessibilityService.requestSwipe(SwipeDirection.PREVIOUS_PAGE)
                    SwipeGesture.NONE -> Unit
                }
            },
            onError = { t ->
                Log.e(TAG, "Hand detection pipeline error; stopping to avoid a broken/looping state", t)
                stopPipeline()
                stopSelf()
            }
        )
        handDetector = hand

        val camera = FrontCameraManager(
            context = this,
            onFrame = { imageProxy -> hand.processFrame(imageProxy, isFrontCamera = true) }
        )
        cameraManager = camera
        camera.start(this)
    }

    private fun stopPipeline() {
        cameraManager?.stop()
        cameraManager = null
        handDetector?.close()
        handDetector = null
        gestureDetector?.reset()
        gestureDetector = null
    }

    override fun onDestroy() {
        stopPipeline()
        super.onDestroy()
    }

    private fun startForegroundWithNotification() {
        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_channel_name))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }
    }
}
