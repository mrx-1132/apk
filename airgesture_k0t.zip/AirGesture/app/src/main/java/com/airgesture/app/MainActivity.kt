package com.airgesture.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.airgesture.app.accessibility.AirGestureAccessibilityService
import com.airgesture.app.service.AirGestureForegroundService
import com.airgesture.app.settings.AirGestureSettings
import com.airgesture.app.settings.SettingsRepository
import com.airgesture.app.ui.MainScreen
import com.airgesture.app.ui.StatusItem
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var settingsRepository: SettingsRepository

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsRepository = SettingsRepository(applicationContext)

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val settings by settingsRepository.settingsFlow.collectAsStateWithLifecycle(
                        initialValue = AirGestureSettings()
                    )

                    var cameraGranted by remember { mutableStateOf(hasCameraPermission()) }
                    var accessibilityEnabled by remember {
                        mutableStateOf(AirGestureAccessibilityService.isEnabledInSystemSettings(this))
                    }

                    // Re-check permission/service state whenever the activity resumes
                    // (e.g. the user comes back from system Settings).
                    LaunchedEffect(Unit) {
                        cameraGranted = hasCameraPermission()
                        accessibilityEnabled = AirGestureAccessibilityService.isEnabledInSystemSettings(this@MainActivity)
                    }

                    val allRequirementsMet = cameraGranted && accessibilityEnabled

                    val statuses = listOf(
                        StatusItem(
                            "Camera permission",
                            cameraGranted,
                            if (cameraGranted) "Granted" else "Required to see your hand"
                        ),
                        StatusItem(
                            "Accessibility Service",
                            accessibilityEnabled,
                            if (accessibilityEnabled) "Enabled" else "Required to perform the swipe"
                        ),
                        StatusItem(
                            "Gesture detection",
                            settings.wantsEnabled && allRequirementsMet,
                            if (settings.wantsEnabled && allRequirementsMet) "Running" else "Stopped"
                        )
                    )

                    MainScreen(
                        masterEnabled = settings.wantsEnabled && allRequirementsMet,
                        onMasterEnabledChange = { enable ->
                            lifecycleScope.launch { settingsRepository.setWantsEnabled(enable) }
                            if (enable && allRequirementsMet) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.POST_NOTIFICATIONS)
                                    != PackageManager.PERMISSION_GRANTED
                                ) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                                AirGestureForegroundService.start(
                                    this@MainActivity,
                                    settings.sensitivity,
                                    settings.cooldownMs
                                )
                            } else {
                                AirGestureForegroundService.stop(this@MainActivity)
                            }
                        },
                        statuses = statuses,
                        sensitivity = settings.sensitivity,
                        onSensitivityChange = { value ->
                            lifecycleScope.launch { settingsRepository.setSensitivity(value) }
                        },
                        cooldownMs = settings.cooldownMs,
                        onCooldownChange = { value ->
                            lifecycleScope.launch { settingsRepository.setCooldownMs(value) }
                        },
                        onOpenAccessibilitySettings = {
                            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        },
                        onRequestCameraPermission = {
                            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                        },
                        allRequirementsMet = allRequirementsMet
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Settings/permission state may have changed while the user was away
        // (e.g. in system Accessibility settings); the Compose state above is
        // re-read the next time recomposition happens via the LaunchedEffect
        // pathway triggered by activity restart, and additionally here we
        // proactively stop the service if the user revoked something needed.
        if (!AirGestureAccessibilityService.isEnabledInSystemSettings(this)) {
            // A hard requirement disappeared (e.g. user disabled Accessibility while
            // away): make sure no orphaned service keeps running with a stale hook.
            AirGestureForegroundService.stop(this)
            lifecycleScope.launch { settingsRepository.setWantsEnabled(false) }
        }
    }

    private fun hasCameraPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
}
