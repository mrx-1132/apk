package com.airgesture.app.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Path
import android.provider.Settings
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

enum class SwipeDirection { NEXT_PAGE, PREVIOUS_PAGE }

/**
 * Performs a system-level horizontal swipe across the Home Screen using the
 * Accessibility gesture-dispatch API. This service does not read window
 * content (canRetrieveWindowContent=false in its config) — it only injects
 * gestures.
 */
class AirGestureAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "AirGestureA11yService"
        private const val SWIPE_DURATION_MS = 380L

        @Volatile
        private var instance: AirGestureAccessibilityService? = null

        fun isServiceInstanceActive(): Boolean = instance != null

        /**
         * Checks whether the user has enabled this service in system
         * Accessibility settings (works even before the service has been
         * instantiated in-process).
         */
        fun isEnabledInSystemSettings(context: Context): Boolean {
            val expectedComponent = "${context.packageName}/${AirGestureAccessibilityService::class.java.name}"
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabledServices.split(':').any { it.equals(expectedComponent, ignoreCase = true) }
        }

        /**
         * Requests a swipe. Returns false if the service isn't currently
         * connected (e.g. user disabled it) — caller should handle this
         * gracefully rather than crash.
         */
        fun requestSwipe(direction: SwipeDirection): Boolean {
            val service = instance ?: run {
                Log.w(TAG, "Swipe requested but accessibility service is not connected")
                return false
            }
            return service.performSwipe(direction)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Accessibility service connected")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty: this service only dispatches gestures, it does
        // not react to accessibility events or inspect window content.
    }

    override fun onInterrupt() {
        // No-op.
    }

    private fun performSwipe(direction: SwipeDirection): Boolean {
        return try {
            val metrics = windowMetricsCompat()
            val width = metrics.first
            val height = metrics.second

            val y = height * 0.5f
            val margin = width * 0.12f

            val (startX, endX) = when (direction) {
                // Hand RIGHT -> LEFT ends up here: swipe the *content* to the
                // left, which visually advances to the next Home Screen page.
                SwipeDirection.NEXT_PAGE -> (width - margin) to margin
                // Hand LEFT -> RIGHT: swipe content to the right -> previous page.
                SwipeDirection.PREVIOUS_PAGE -> margin to (width - margin)
            }

            val path = Path().apply {
                moveTo(startX, y)
                lineTo(endX, y)
            }

            val stroke = GestureDescription.StrokeDescription(path, 0, SWIPE_DURATION_MS)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()

            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    Log.d(TAG, "Swipe completed: $direction")
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    Log.w(TAG, "Swipe cancelled: $direction")
                }
            }, null)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to dispatch swipe", t)
            false
        }
    }

    /** Returns (widthPx, heightPx) using the modern WindowMetrics API where available. */
    private fun windowMetricsCompat(): Pair<Float, Float> {
        return try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val bounds = wm.currentWindowMetrics.bounds
            (bounds.width().toFloat()) to (bounds.height().toFloat())
        } catch (t: Throwable) {
            val dm = resources.displayMetrics
            dm.widthPixels.toFloat() to dm.heightPixels.toFloat()
        }
    }
}
