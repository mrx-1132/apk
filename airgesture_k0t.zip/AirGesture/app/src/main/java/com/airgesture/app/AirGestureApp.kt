package com.airgesture.app

import android.app.Application

class AirGestureApp : Application()
