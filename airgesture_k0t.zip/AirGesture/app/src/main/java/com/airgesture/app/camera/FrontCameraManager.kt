package com.airgesture.app.camera

import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.LifecycleOwner
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Owns the CameraX pipeline for the front camera. Frames are delivered on a
 * dedicated background executor via [onFrame]; the caller (HandDetector) is
 * responsible for closing each [ImageProxy] once done.
 *
 * The camera preview is intentionally never attached to any UI Surface: only
 * a headless [ImageAnalysis] use case is bound, per the requirement that this
 * is not a camera-preview app.
 */
class FrontCameraManager(
    private val context: Context,
    private val onFrame: (ImageProxy) -> Unit
) {
    companion object {
        private const val TAG = "FrontCameraManager"
    }

    private var cameraProvider: ProcessCameraProvider? = null
    private var analysisExecutor: ExecutorService? = null
    private var started = false

    fun isRunning(): Boolean = started

    fun start(lifecycleOwner: LifecycleOwner) {
        if (started) return
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                cameraProvider = provider

                val executor = Executors.newSingleThreadExecutor()
                analysisExecutor = executor

                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor) { imageProxy ->
                    try {
                        onFrame(imageProxy)
                    } catch (t: Throwable) {
                        Log.e(TAG, "Frame processing failed", t)
                        imageProxy.close()
                    }
                }

                val selector = CameraSelector.DEFAULT_FRONT_CAMERA

                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, selector, analysis)
                started = true
            } catch (t: Throwable) {
                Log.e(TAG, "Failed to start camera", t)
                started = false
            }
        }, androidx.core.content.ContextCompat.getMainExecutor(context))
    }

    fun stop() {
        started = false
        try {
            cameraProvider?.unbindAll()
        } catch (t: Throwable) {
            Log.w(TAG, "Error unbinding camera", t)
        }
        cameraProvider = null
        analysisExecutor?.shutdown()
        analysisExecutor = null
    }
}
