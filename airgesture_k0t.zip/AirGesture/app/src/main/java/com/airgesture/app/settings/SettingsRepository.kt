package com.airgesture.app.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "air_gesture_settings")

data class AirGestureSettings(
    /** Whether the user last left the feature toggled on. Restoring this does
     *  NOT by itself start the camera — MainActivity always requires the
     *  user to be present and permissions/services to be verified first. */
    val wantsEnabled: Boolean = false,
    val sensitivity: Float = 0.5f,
    val cooldownMs: Long = 900L
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val WANTS_ENABLED = booleanPreferencesKey("wants_enabled")
        val SENSITIVITY = floatPreferencesKey("sensitivity")
        val COOLDOWN_MS = longPreferencesKey("cooldown_ms")
    }

    val settingsFlow: Flow<AirGestureSettings> = context.dataStore.data.map { prefs ->
        AirGestureSettings(
            wantsEnabled = prefs[Keys.WANTS_ENABLED] ?: false,
            sensitivity = prefs[Keys.SENSITIVITY] ?: 0.5f,
            cooldownMs = prefs[Keys.COOLDOWN_MS] ?: 900L
        )
    }

    suspend fun setWantsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.WANTS_ENABLED] = enabled }
    }

    suspend fun setSensitivity(sensitivity: Float) {
        context.dataStore.edit { it[Keys.SENSITIVITY] = sensitivity.coerceIn(0f, 1f) }
    }

    suspend fun setCooldownMs(cooldownMs: Long) {
        context.dataStore.edit { it[Keys.COOLDOWN_MS] = cooldownMs.coerceIn(300L, 3000L) }
    }
}
