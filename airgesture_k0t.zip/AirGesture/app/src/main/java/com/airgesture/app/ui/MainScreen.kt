package com.airgesture.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class StatusItem(val label: String, val ok: Boolean, val detail: String)

@Composable
fun MainScreen(
    masterEnabled: Boolean,
    onMasterEnabledChange: (Boolean) -> Unit,
    statuses: List<StatusItem>,
    sensitivity: Float,
    onSensitivityChange: (Float) -> Unit,
    cooldownMs: Long,
    onCooldownChange: (Long) -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onRequestCameraPermission: () -> Unit,
    allRequirementsMet: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Air Gesture", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Move your hand horizontally in front of the front camera.",
            style = MaterialTheme.typography.bodyMedium
        )

        Card(colors = CardDefaults.cardColors()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Enable Air Gestures", style = MaterialTheme.typography.titleMedium)
                    if (!allRequirementsMet) {
                        Text(
                            "Finish the setup steps below first",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
                Switch(
                    checked = masterEnabled,
                    onCheckedChange = onMasterEnabledChange,
                    enabled = allRequirementsMet || masterEnabled
                )
            }
        }

        Card {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Status", style = MaterialTheme.typography.titleMedium)
                statuses.forEach { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(item.label, style = MaterialTheme.typography.bodyLarge)
                            Text(item.detail, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(if (item.ok) "OK" else "Needed", style = MaterialTheme.typography.bodyLarge)
                    }
                    Divider()
                }
                Button(onClick = onRequestCameraPermission) {
                    Text("Grant camera permission")
                }
                Button(onClick = onOpenAccessibilitySettings) {
                    Text("Open Accessibility settings")
                }
            }
        }

        Card {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Sensitivity", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Higher sensitivity needs less hand movement to trigger a swipe.",
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(value = sensitivity, onValueChange = onSensitivityChange, valueRange = 0f..1f)
            }
        }

        Card {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Gesture cooldown: ${cooldownMs} ms", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Minimum time between two swipes, to avoid accidental repeats.",
                    style = MaterialTheme.typography.bodySmall
                )
                Slider(
                    value = cooldownMs.toFloat(),
                    onValueChange = { onCooldownChange(it.toLong()) },
                    valueRange = 300f..3000f
                )
            }
        }

        Card {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("MIUI tips", style = MaterialTheme.typography.titleMedium)
                Text(
                    "MIUI may kill background services aggressively. If gestures stop working after a " +
                        "while, check Settings > Apps > Air Gesture > Autostart, Battery saver, and " +
                        "Background activity, and make sure Accessibility access stays enabled.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
