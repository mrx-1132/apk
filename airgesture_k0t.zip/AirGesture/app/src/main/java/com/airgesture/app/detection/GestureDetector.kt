package com.airgesture.app.detection

import java.util.ArrayDeque

/**
 * One observation of the tracked hand for a single processed camera frame.
 *
 * [x] and [y] are normalized to 0f..1f (already mirror-corrected so that
 * increasing x means the hand moved towards the user's right hand side,
 * regardless of how the front camera physically mirrors the image).
 */
data class HandSample(
    val x: Float,
    val y: Float,
    val timestampMs: Long,
    val present: Boolean
)

enum class SwipeGesture { NONE, SWIPE_NEXT, SWIPE_PREVIOUS }

/**
 * Tunable parameters. All defaults were chosen empirically for a phone held
 * ~25-40cm from the face with the hand crossing roughly a third of the
 * frame width; they are intentionally exposed so the UI can turn a single
 * "sensitivity" slider into concrete values.
 */
data class GestureConfig(
    /** How far back in time (ms) we look when evaluating a swipe. */
    val historyWindowMs: Long = 700,
    /** Minimum time span (ms) the current window must cover before we ever evaluate it. */
    val minWindowSpanMs: Long = 120,
    /** Minimum normalized horizontal displacement required to count as a swipe. */
    val minHorizontalDisplacement: Float = 0.22f,
    /** Horizontal displacement must be at least this many times the vertical displacement. */
    val horizontalDominanceFactor: Float = 1.4f,
    /**
     * If a single frame-to-frame jump in x exceeds this, it is treated as a tracking
     * glitch (not real hand motion) and the history is discarded rather than used.
     */
    val maxSingleSampleJump: Float = 0.35f,
    /** Cooldown after a successful trigger, during which no new gesture can fire. */
    val cooldownMs: Long = 900
) {
    companion object {
        /** Maps a single 0f..1f "sensitivity" slider to a concrete config. Higher = easier to trigger. */
        fun fromSensitivity(sensitivity: Float, cooldownMs: Long): GestureConfig {
            val s = sensitivity.coerceIn(0f, 1f)
            return GestureConfig(
                minHorizontalDisplacement = 0.32f - (0.18f * s), // 0.32 (low) .. 0.14 (high)
                horizontalDominanceFactor = 1.7f - (0.5f * s),   // 1.7 (strict) .. 1.2 (loose)
                cooldownMs = cooldownMs
            )
        }
    }
}

/**
 * Stateful horizontal swipe detector. Feed it every processed frame via
 * [process]; it is not thread-safe and is meant to be driven from a single
 * background analysis thread.
 */
class GestureDetector(private val config: GestureConfig = GestureConfig()) {

    private val window = ArrayDeque<HandSample>()
    private var lastSample: HandSample? = null
    private var cooldownUntilMs: Long = 0L

    fun reset() {
        window.clear()
        lastSample = null
        cooldownUntilMs = 0L
    }

    fun process(sample: HandSample): SwipeGesture {
        // Hand lost: any in-progress motion is invalidated. A gesture must be
        // observed continuously from start to finish.
        if (!sample.present) {
            window.clear()
            lastSample = sample
            return SwipeGesture.NONE
        }

        val previous = lastSample
        lastSample = sample

        // Sudden, physically-implausible jump between consecutive frames -> tracking
        // glitch. Discard accumulated history and start fresh from this sample.
        if (previous != null && previous.present) {
            val dx = kotlin.math.abs(sample.x - previous.x)
            if (dx > config.maxSingleSampleJump) {
                window.clear()
            }
        }

        window.addLast(sample)
        dropExpiredSamples(sample.timestampMs)

        val inCooldown = sample.timestampMs < cooldownUntilMs
        if (inCooldown) {
            return SwipeGesture.NONE
        }

        val first = window.peekFirst() ?: return SwipeGesture.NONE
        val span = sample.timestampMs - first.timestampMs
        if (span < config.minWindowSpanMs) {
            return SwipeGesture.NONE
        }

        val dx = sample.x - first.x
        val dy = sample.y - first.y
        val absDx = kotlin.math.abs(dx)
        val absDy = kotlin.math.abs(dy)

        if (absDx < config.minHorizontalDisplacement) {
            return SwipeGesture.NONE
        }
        if (absDx < absDy * config.horizontalDominanceFactor) {
            // Movement was not predominantly horizontal.
            return SwipeGesture.NONE
        }

        // Trigger. Clear history and start the cooldown so the hand must produce a
        // fresh, distinct movement (functionally requiring a return-to-neutral)
        // before another gesture can register.
        window.clear()
        cooldownUntilMs = sample.timestampMs + config.cooldownMs

        return if (dx < 0) {
            // x decreased => hand moved from the user's right towards their left.
            SwipeGesture.SWIPE_NEXT
        } else {
            SwipeGesture.SWIPE_PREVIOUS
        }
    }

    private fun dropExpiredSamples(nowMs: Long) {
        while (true) {
            val oldest = window.peekFirst() ?: break
            if (nowMs - oldest.timestampMs > config.historyWindowMs) {
                window.pollFirst()
            } else {
                break
            }
        }
    }
}
