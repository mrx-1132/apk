package com.airgesture.app.detection

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult

/**
 * Wraps MediaPipe's HandLandmarker to turn raw CameraX frames into a stream
 * of [HandSample]s expressed in the "hand moved towards the user's right =
 * increasing x" coordinate space that [GestureDetector] expects.
 *
 * The model file (hand_landmarker.task) must be present in
 * app/src/main/assets/. See README.md for how to obtain it — it is a Google
 * asset that must be downloaded from Google's model repository; it is not
 * safe or correct to invent/fabricate this binary file.
 */
class HandDetector(
    context: Context,
    private val onResult: (HandSample) -> Unit,
    private val onError: (Throwable) -> Unit
) {
    companion object {
        private const val TAG = "HandDetector"
        private const val MODEL_ASSET_PATH = "hand_landmarker.task"
        // Landmark 0 is the wrist, the most stable single point for tracking
        // gross hand position (fingertips are noisier and can vanish under
        // partial occlusion).
        private const val WRIST_LANDMARK_INDEX = 0
    }

    private var landmarker: HandLandmarker? = null
    @Volatile private var closed = false

    init {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath(MODEL_ASSET_PATH)
                .setDelegate(Delegate.CPU)
                .build()

            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setResultListener(::handleResult)
                .setErrorListener { e ->
                    Log.e(TAG, "MediaPipe error", e)
                    onError(e)
                }
                .build()

            landmarker = HandLandmarker.createFromOptions(context, options)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to initialize HandLandmarker", t)
            onError(t)
        }
    }

    /** Call from the CameraX analyzer thread. Closes [imageProxy] when done. */
    fun processFrame(imageProxy: ImageProxy, isFrontCamera: Boolean) {
        val currentLandmarker = landmarker
        if (closed || currentLandmarker == null) {
            imageProxy.close()
            return
        }
        try {
            val bitmap = imageProxyToBitmap(imageProxy, isFrontCamera)
            val mpImage = BitmapImageBuilder(bitmap).build()
            val timestampMs = System.currentTimeMillis()
            currentLandmarker.detectAsync(mpImage, timestampMs)
        } catch (t: Throwable) {
            Log.e(TAG, "Failed to process frame", t)
            onError(t)
        } finally {
            imageProxy.close()
        }
    }

    private fun handleResult(result: HandLandmarkerResult, image: com.google.mediapipe.framework.image.MPImage) {
        val timestampMs = System.currentTimeMillis()
        val landmarksList = result.landmarks()
        if (landmarksList.isEmpty()) {
            onResult(HandSample(0f, 0f, timestampMs, present = false))
            return
        }
        val hand = landmarksList[0]
        val wrist = hand.getOrNull(WRIST_LANDMARK_INDEX) ?: hand[0]

        // MediaPipe returns x in 0..1 across the bitmap we fed it. Because
        // imageProxyToBitmap() already mirrors the front-camera frame into
        // "selfie view" (matching what the user sees of themselves), the
        // model's x already increases towards the user's own right hand, so
        // no further flip is needed here.
        onResult(HandSample(x = wrist.x(), y = wrist.y(), timestampMs = timestampMs, present = true))
    }

    /**
     * Converts a CameraX YUV frame to an ARGB [Bitmap], applying the frame's
     * rotation and, for the front camera, a horizontal mirror so the image
     * matches what the user sees of themselves (selfie orientation). This is
     * what keeps "hand moves right" meaning "right from the user's own point
     * of view" rather than being flipped by the physically mirrored sensor.
     */
    private fun imageProxyToBitmap(imageProxy: ImageProxy, isFrontCamera: Boolean): Bitmap {
        val rotationDegrees = imageProxy.imageInfo.rotationDegrees
        val bitmap = yuv420ToBitmap(imageProxy)
        val matrix = android.graphics.Matrix()
        matrix.postRotate(rotationDegrees.toFloat())
        if (isFrontCamera) {
            matrix.postScale(-1f, 1f)
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun yuv420ToBitmap(imageProxy: ImageProxy): Bitmap {
        val yBuffer = imageProxy.planes[0].buffer
        val uBuffer = imageProxy.planes[1].buffer
        val vBuffer = imageProxy.planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        val yuvImage = android.graphics.YuvImage(
            nv21, android.graphics.ImageFormat.NV21, imageProxy.width, imageProxy.height, null
        )
        val out = java.io.ByteArrayOutputStream()
        yuvImage.compressToJpeg(android.graphics.Rect(0, 0, imageProxy.width, imageProxy.height), 90, out)
        val jpegBytes = out.toByteArray()
        return android.graphics.BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
    }

    fun close() {
        closed = true
        try {
            landmarker?.close()
        } catch (t: Throwable) {
            Log.w(TAG, "Error closing HandLandmarker", t)
        }
        landmarker = null
    }
}
