package com.airgesture.app.detection

import org.junit.Assert.assertEquals
import org.junit.Test

class GestureDetectorTest {

    private val config = GestureConfig(
        historyWindowMs = 700,
        minWindowSpanMs = 100,
        minHorizontalDisplacement = 0.20f,
        horizontalDominanceFactor = 1.4f,
        maxSingleSampleJump = 0.35f,
        cooldownMs = 800
    )

    private fun detector() = GestureDetector(config)

    /**
     * Feeds a smooth linear sweep in x (and optionally y) from [fromX]/[fromY] to
     * [toX]/[toY] and returns the FIRST non-NONE result observed anywhere during
     * the sweep (a trigger clears history and starts a cooldown, so later frames
     * in the same sweep will correctly report NONE — the caller wants to know
     * whether the sweep ever fired, not just how the final frame behaved).
     */
    private fun sweep(
        detector: GestureDetector,
        fromX: Float,
        toX: Float,
        fromY: Float = 0.5f,
        toY: Float = 0.5f,
        steps: Int = 8,
        startTimeMs: Long = 0L,
        stepMs: Long = 30L,
        dropLastNSamples: Int = 0
    ): SwipeGesture {
        var triggered = SwipeGesture.NONE
        val usableSteps = steps - dropLastNSamples
        for (i in 0..steps) {
            val t = startTimeMs + i * stepMs
            val result: SwipeGesture
            if (i > usableSteps) {
                // Simulate the hand disappearing before the sweep completes.
                result = detector.process(HandSample(0f, 0f, t, present = false))
            } else {
                val frac = i / steps.toFloat()
                val x = fromX + (toX - fromX) * frac
                val y = fromY + (toY - fromY) * frac
                result = detector.process(HandSample(x, y, t, present = true))
            }
            if (result != SwipeGesture.NONE && triggered == SwipeGesture.NONE) {
                triggered = result
            }
        }
        return triggered
    }

    @Test
    fun `right to left produces NEXT`() {
        val d = detector()
        val result = sweep(d, fromX = 0.85f, toX = 0.15f)
        assertEquals(SwipeGesture.SWIPE_NEXT, result)
    }

    @Test
    fun `left to right produces PREVIOUS`() {
        val d = detector()
        val result = sweep(d, fromX = 0.15f, toX = 0.85f)
        assertEquals(SwipeGesture.SWIPE_PREVIOUS, result)
    }

    @Test
    fun `tiny movement produces NONE`() {
        val d = detector()
        val result = sweep(d, fromX = 0.50f, toX = 0.55f)
        assertEquals(SwipeGesture.NONE, result)
    }

    @Test
    fun `vertical movement produces NONE`() {
        val d = detector()
        val result = sweep(d, fromX = 0.50f, toX = 0.55f, fromY = 0.20f, toY = 0.80f)
        assertEquals(SwipeGesture.NONE, result)
    }

    @Test
    fun `stationary hand produces NONE`() {
        val d = detector()
        var result = SwipeGesture.NONE
        for (i in 0..8) {
            result = d.process(HandSample(0.5f, 0.5f, i * 30L, present = true))
        }
        assertEquals(SwipeGesture.NONE, result)
    }

    @Test
    fun `tracking jitter produces NONE`() {
        val d = detector()
        val jitter = floatArrayOf(0.50f, 0.51f, 0.49f, 0.505f, 0.495f, 0.50f, 0.502f, 0.498f, 0.50f)
        var result = SwipeGesture.NONE
        for ((i, x) in jitter.withIndex()) {
            result = d.process(HandSample(x, 0.5f, i * 30L, present = true))
        }
        assertEquals(SwipeGesture.NONE, result)
    }

    @Test
    fun `second gesture during cooldown produces NONE`() {
        val d = detector()
        val first = sweep(d, fromX = 0.85f, toX = 0.15f, startTimeMs = 0L)
        assertEquals(SwipeGesture.SWIPE_NEXT, first)

        // Immediately attempt another swipe, well inside the 800ms cooldown.
        val second = sweep(d, fromX = 0.15f, toX = 0.85f, startTimeMs = 260L, stepMs = 10L)
        assertEquals(SwipeGesture.NONE, second)
    }

    @Test
    fun `gesture after cooldown elapses is valid`() {
        val d = detector()
        val first = sweep(d, fromX = 0.85f, toX = 0.15f, startTimeMs = 0L)
        assertEquals(SwipeGesture.SWIPE_NEXT, first)

        // Start well after the 800ms cooldown window has passed.
        val second = sweep(d, fromX = 0.15f, toX = 0.85f, startTimeMs = 2000L)
        assertEquals(SwipeGesture.SWIPE_PREVIOUS, second)
    }

    @Test
    fun `large sudden tracking jump produces NONE`() {
        val d = detector()
        var result = d.process(HandSample(0.20f, 0.5f, 0L, present = true))
        assertEquals(SwipeGesture.NONE, result)
        // A single-frame jump far larger than maxSingleSampleJump (0.35): treated
        // as a glitch, history is cleared, so it cannot be read as a valid swipe.
        result = d.process(HandSample(0.95f, 0.5f, 30L, present = true))
        assertEquals(SwipeGesture.NONE, result)
        // Only a little more motion follows, not enough on its own to trigger.
        result = d.process(HandSample(0.97f, 0.5f, 60L, present = true))
        assertEquals(SwipeGesture.NONE, result)
    }

    @Test
    fun `hand disappearing mid-gesture produces NONE`() {
        val d = detector()
        // Tracked for only the first 2 of 8 steps (25% of the sweep, well under
        // both the displacement and min-window-span thresholds) before the hand
        // is lost, so no partial credit should accumulate across the gap.
        val result = sweep(d, fromX = 0.85f, toX = 0.15f, steps = 8, dropLastNSamples = 6)
        assertEquals(SwipeGesture.NONE, result)
    }
}
